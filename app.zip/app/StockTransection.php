<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class StockTransection extends Model
{
    //
}
