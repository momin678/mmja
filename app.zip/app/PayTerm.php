<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PayTerm extends Model
{
    //
}
