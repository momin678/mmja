<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Fifo extends Model
{
    //
    protected $fillable=['unit_cost_price'];
}
