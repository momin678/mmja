<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class InvoiceDraft extends Model
{

}
