<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TransectionDefinition extends Model
{
    //
}
