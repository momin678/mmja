<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PurchseDetail extends Model
{
    //
}
