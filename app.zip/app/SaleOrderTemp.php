<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SaleOrderTemp extends Model
{
    //
}
