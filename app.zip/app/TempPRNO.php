<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class TempPRNO extends Model
{
    //
}
