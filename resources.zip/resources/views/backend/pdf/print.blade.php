@extends('layouts.pdf.pageBrekApp')
  @section('content')
 <div class="col-10">
    <section class="page-break">Paragraph 1</section>
    <div class="page-break">Paragraph 2</div>
 </div>
  @endsection
