<div class="img">
    <img src="{{ asset('img/finallogo000.jpeg') }}" class="img-fluid" style="position: fixed; top:350px; left:270px; opacity:0.1; " >
</div>
<style>
    .divFooter {
        /* position: fixed; */
        bottom: 0;
    }
</style>
<section>
    <div class="divFooter m-2">
        Business Software Solutions Powered by
        <span style="color: #0005" class="spanStyle"><img class="img-fluid" src="{{ asset('assets/backend/app-assets/zisprink.png')}}" alt="" width="70"></span>
    </div>
</section>